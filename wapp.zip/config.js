var config = {
	debug: false,
	database: {
		host: "localhost",
		user: "bharatco_uswap",
		password: "42vuh#z9S22v4*",
		database: "bharatco_wapdb",
		charset : "utf8mb4"
	},
	cors: {
		origin: '*',
 		optionsSuccessStatus: 200
	}
}

module.exports = config; 