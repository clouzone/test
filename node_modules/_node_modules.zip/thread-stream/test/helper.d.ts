export declare function file(): string
