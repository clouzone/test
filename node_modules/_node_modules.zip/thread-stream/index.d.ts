import { EventEmitter } from 'events'

declare class ThreadStream extends EventEmitter {
  constructor(opts: {})
  write (data: string): boolean
  end (): void
}

export = ThreadStream;
